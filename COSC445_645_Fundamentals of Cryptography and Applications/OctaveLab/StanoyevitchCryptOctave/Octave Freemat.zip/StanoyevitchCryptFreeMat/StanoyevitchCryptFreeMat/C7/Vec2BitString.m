function Str = Vec2BitString(Vec)
% Str = Vec2BitString(Vec)
% Input:  Vec = a vector of integers mod 2
% Output: Str = the corresponding string
Str = char(Vec+48);