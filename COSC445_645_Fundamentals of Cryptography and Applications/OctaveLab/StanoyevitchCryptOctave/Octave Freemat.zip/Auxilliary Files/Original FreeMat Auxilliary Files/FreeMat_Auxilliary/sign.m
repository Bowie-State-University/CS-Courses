function s = sign(a)
% s = sign(a)
if a > 0
    s = 1;
elseif a < 0
    s = -1;
else
    s = 0;
end